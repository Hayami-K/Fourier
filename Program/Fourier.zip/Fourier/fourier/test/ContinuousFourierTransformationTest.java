package fourier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ContinuousFourierTransformationTest {

    @Test
    @DisplayName("連続フーリエ変換をする単体テスト")
    public void testTransform() {
        ContinuousFourierTransformation cft = new ContinuousFourierTransformation();
        FourierTransformation result = cft.transform();
        assertNotNull(result);
    }

    @Test
    @DisplayName("逆連続フーリエ変換をする単体テスト")
    public void testInverseTransform() {
        ContinuousFourierTransformation cft = new ContinuousFourierTransformation();
        FourierTransformation result = cft.inverseTransform();
        assertNotNull(result);
    }
}
