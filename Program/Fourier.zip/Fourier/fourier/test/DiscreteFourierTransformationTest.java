package fourier;

import fourier.DiscreteFourierTransformation;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

public class DiscreteFourierTransformationTest {

    /**
     * 
     */
    @Test
    @DisplayName("スワップし、一次元配列を決めるクラスの単体テスト")
    public void testSwap1D() {
        DiscreteFourierTransformation dft = new DiscreteFourierTransformationImpl();
        double[] input = {1, 2, 3, 4, 5, 6};
        double[] expected = {4, 5, 6, 1, 2, 3};
        double[] result = dft.swap(input);
        assertArrayEquals(expected, result);
    }

    /**
     * 
     */
    @Test
    @DisplayName("スワップし、二次元配列を決めるクラスの単体テスト")
    public void testSwap2D() {
        DiscreteFourierTransformation dft = new DiscreteFourierTransformationImpl();
        double[][] input = {{2 , 1}, {3 , 4}};
        double[][] expected = {{4 , 3}, {1 , 2}};
        double[][] result = dft.swap(input);
        assertArrayEquals(expected, result);
    }

    
    private class DiscreteFourierTransformationImpl extends DiscreteFourierTransformation {
        @Override
        protected void flush() {
            // メソッドの実装
        }

        @Override
        public DiscreteFourierTransformation transform() {
            // メソッドの実装
            return null;
        }

        @Override
        public DiscreteFourierTransformation inverseTransform() {
            // メソッドの実装
            return null;
        }
    }
}
