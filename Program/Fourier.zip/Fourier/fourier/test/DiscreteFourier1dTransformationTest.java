package fourier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.Assert.*;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import org.junit.jupiter.api.Assertions;

public class DiscreteFourier1dTransformationTest{

    @Test
    @DisplayName("実部だけ指定するコンストラクタの単体テスト")
    public void testDiscreteFourier1dTransformationConstructor() {
        double[] testData = {1.0 , 2.0 , 3.0};
        DiscreteFourier1dTransformation transform = new DiscreteFourier1dTransformation(testData);
        assertNotNull(transform);
    }

    
    @Test
    @DisplayName("実部と虚部を指定するコンストラクタの単体テスト")
    public void testDiscreteFourier1dTransformation()
	{
		double[] testRealData = {1.0 , 2.0 , 3.0};
        double[] testImaginaryData = {0.0 , 0.0 , 0.0};
        DiscreteFourier1dTransformation transform = new DiscreteFourier1dTransformation(testRealData, testImaginaryData);
        assertNotNull(transform);
	}

    @Test
    @DisplayName("フーリエ変換を水に流すコンストラクタの単体テスト")
    public void testflush()
        throws NoSuchMethodException,
        SecurityException,
        IllegalAccessException,
        IllegalArgumentException,
        InvocationTargetException
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData, imaginaryData);
        Method method = DiscreteFourier1dTransformation.class.getDeclaredMethod("flush");
        method.setAccessible(true);
        transformation.flush();
        double[] destinationRealPart = transformation.destinationRealPart;
        double[] destinationImaginaryPart = transformation.destinationImaginaryPart;
        assertNull(destinationRealPart);
        assertNull(destinationImaginaryPart);
    }
    
    @Test
    @DisplayName("フーリエ変換を施した虚部に応答するコンストラクタの単体テスト")
    public void testimaginaryPart()
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData, imaginaryData);
        double[] result = transformation.imaginaryPart();
        assertEquals(transformation.destinationImaginaryPart, result);
    }

    @Test
    @DisplayName("フーリエ変換を初期化するコンストラクタの単体テスト")
    public void testinitialize()
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData, imaginaryData);
        double[] result = transformation.imaginaryPart();
        assertEquals(transformation.destinationImaginaryPart, result);
    }

    @Test
    @DisplayName("逆変換を施した虚部に対応するコンストラクタの単体テスト")
    public void testinverseImaginaryPart()
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData, imaginaryData);
        assertNull(transformation.destinationImaginaryPart);
        transformation.inverseImaginaryPart();
        assertNotNull(transformation.destinationImaginaryPart);
    }

    @Test
    @DisplayName("逆変換を施した実部に対応するコンストラクタの単体テスト")
    public void testinverseRealPart()
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData, imaginaryData);
        assertNull(transformation.destinationRealPart);
        transformation.inverseRealPart();
        assertNotNull(transformation.destinationRealPart);
    }

    @Test
    @DisplayName("逆フーリエ変換を施すクラスの単体テスト")
    public void testinverseTransform()
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData, imaginaryData);
        assertNull(transformation.destinationRealPart);
        assertNull(transformation.destinationImaginaryPart);
        transformation.inverseTransform();
        assertNotNull(transformation.destinationRealPart);
        assertNotNull(transformation.destinationImaginaryPart);
    }

    @Test
    @DisplayName("整数が2のN乗かを応答するクラスの単体テスト")
    public void testisPowerOfTwo()
        throws NoSuchMethodException,
        SecurityException,
        IllegalAccessException,
        IllegalArgumentException,
        InvocationTargetException
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation two = new DiscreteFourier1dTransformation(realData , imaginaryData);
        Method method = DiscreteFourier1dTransformation.class.getDeclaredMethod("isPowerOfTwo" , int.class);
        method.setAccessible(true);
        assertTrue((boolean) method.invoke(two, 2)); //整数が2のN乗の形
        assertTrue((boolean) method.invoke(two, 1024));
        assertFalse((boolean) method.invoke(two, 3)); //整数が2のN乗の形になっていない
        assertFalse((boolean) method.invoke(two, 1000));
    } 

    @Test
    @DisplayName("配列の対数をとるクラスの単体テスト")
    public void testlogarithmicArray()
    {
        double[] inputArray = {1.0, 2.0, 3.0, 4.0, 5.0};
        double[] expectedArray = {0.0, 0.6931471805599453, 1.0986122886681098, 1.3862943611198906, 1.6094379124341003};
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData , imaginaryData);
        double[] resultArray = transformation.logarithmicArray(inputArray);
        Assertions.assertArrayEquals(expectedArray, resultArray, 1e-9);
    }

    @Test
    @DisplayName("配列を正規化するクラスの単体テスト")
    public void testnormalizedArray()
    {
        double[] inputArray = {1.0, 2.0, 3.0, 4.0, 5.0};
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData , imaginaryData);
        double[] resultArray = transformation.normalizedArray(inputArray);
        assertArrayEquals(new double[]{0.2, 0.4, 0.6, 0.8, 1.0}, resultArray, 0.0001);
    }

    @Test
    @DisplayName("正規化対数パワースペクトルを求めるクラスの単体テスト")
    public void testpowerOfTwo()
    throws NoSuchMethodException,
        SecurityException,
        IllegalAccessException,
        IllegalArgumentException,
        InvocationTargetException
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation two = new DiscreteFourier1dTransformation(realData , imaginaryData);
        Method method = DiscreteFourier1dTransformation.class.getDeclaredMethod("powerOfTwo" , int.class);
        method.setAccessible(true);
        assertEquals(1, (int) method.invoke(two, 2));
        assertEquals(10, (int) method.invoke(two, 1024));
        assertEquals(0, (int) method.invoke(two, 5));
    }

    @Test
    @DisplayName("パワースペクトルを求めるクラスの単体テスト")
    public void testpowerSpectrum()
    {
        double[] realData = {1.0 , 2.0 , 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData, imaginaryData);
        double[] powerSpectrum = transformation.powerSpectrum();
        double[] expectedPowerSpectrum = {36.0, 3.0, 3.0};
        assertArrayEquals(expectedPowerSpectrum, powerSpectrum, 1e-6);
    }

    @Test
    @DisplayName("実部を求めるクラスの単体テスト")
    public void testrealPart()
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData, imaginaryData);
        double[] customRealData = {4.0, 5.0, 6.0};
        transformation.destinationRealPart = customRealData;
        double[] result2 = transformation.realPart();
        assertSame(customRealData, result2); 
    }

    @Test
    @DisplayName("スペクトルを求めるクラスの単体テスト")
    public void testspectrum()
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData, imaginaryData);
        double[] inputPowerSpectrum = {1.0, 4.0, 9.0};
        double[] expectedSpectrum = {6.0, 1.7320508075688776, 1.7320508075688776};
        double[] spectrum = transformation.spectrum();
        assertArrayEquals(expectedSpectrum, spectrum, 1e-10);
    }

    @Test
    @DisplayName("配列の平方根を求めるクラスの単体テスト")
    public void testsquareRootArray()
    {
        double[] realData = {1.0, 2.0, 3.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData);
        double[] inputArray = {1.0, 4.0, 9.0};
        double[] expectedArray = {1.0, 2.0, 3.0};
        double[] resultArray = transformation.squareRootArray(inputArray);
        assertArrayEquals(expectedArray, resultArray, 1e-10);
    }

    @Test
    @DisplayName("フーリエ変換を施すクラスの単体テスト")
    public void testtransform()
        throws NoSuchMethodException,
        SecurityException,
        IllegalAccessException,
        IllegalArgumentException,
        InvocationTargetException
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData , imaginaryData);
        Method method = DiscreteFourier1dTransformation.class.getDeclaredMethod("transform" , int.class);
        method.setAccessible(true);

        int flag1 = 1;
        double[] expectedRealPart1 = {6.0, -1.4999999999999998, -1.4999999999999996};
        double[] expectedImaginaryPart1 = {0.0, -0.8660254037844388, 0.8660254037844386};
        transformation.transform(flag1);
        assertArrayEquals(expectedRealPart1, transformation.destinationRealPart, 1e-10);
        assertArrayEquals(expectedImaginaryPart1, transformation.destinationImaginaryPart, 1e-10);

        int flag2 = -1;
        double[] expectedRealPart2 = {2.0, -0.4999999999999999, -0.4999999999999999};
        double[] expectedImaginaryPart2 = {0.0, 0.28867513459481287, -0.28867513459481287};
        transformation.transform(flag2);
        assertArrayEquals(expectedRealPart2, transformation.destinationRealPart, 1e-10);
        assertArrayEquals(expectedImaginaryPart2, transformation.destinationImaginaryPart, 1e-10);
    }

    @Test
    @DisplayName("高速フーリエ変換を行うクラスの単体テスト")
    public void testturboTransform()
        throws NoSuchMethodException,
        SecurityException,
        IllegalAccessException,
        IllegalArgumentException,
        InvocationTargetException
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData , imaginaryData);
        Method method = DiscreteFourier1dTransformation.class.getDeclaredMethod("transform" , int.class);
        method.setAccessible(true);

        int flag1 = 1;
        double[] expectedRealPart1 = {6.0, -1.4999999999999998, -1.4999999999999996};
        double[] expectedImaginaryPart1 = {0.0, -0.8660254037844388, 0.8660254037844386};
        transformation.transform(flag1);
        assertArrayEquals(expectedRealPart1, transformation.destinationRealPart, 1e-10);
        assertArrayEquals(expectedImaginaryPart1, transformation.destinationImaginaryPart, 1e-10);

        int flag2 = -1;
        double[] expectedRealPart2 = {2.0, -0.4999999999999999, -0.4999999999999999};
        double[] expectedImaginaryPart2 = {0.0, 0.28867513459481287, -0.28867513459481287};
        transformation.transform(flag2);
        assertArrayEquals(expectedRealPart2, transformation.destinationRealPart, 1e-10);
        assertArrayEquals(expectedImaginaryPart2, transformation.destinationImaginaryPart, 1e-10);
    }

    @Test
    @DisplayName("Cooley-Tukeyのアルゴリズムを適用するための準備をするクラスの単体テスト")
    public void testturboTransformInitialize()
        throws NoSuchMethodException,
        SecurityException,
        IllegalAccessException,
        IllegalArgumentException,
        InvocationTargetException
    {
        double[] realData = {1.0, 2.0, 3.0};
        double[] imaginaryData = {0.0, 0.0, 0.0};
        DiscreteFourier1dTransformation transformation = new DiscreteFourier1dTransformation(realData , imaginaryData);
        Method method = DiscreteFourier1dTransformation.class.getDeclaredMethod("turboTransformInitialize" , double[].class , double[].class , int.class);
        method.setAccessible(true);

        double[] x = {1.0, 2.0, 3.0, 4.0};
        double[] y = {0.0, 0.0, 0.0, 0.0};
        method.invoke(transformation, x, y, 2);
        double[] expectedX = {1.0, 3.0, 2.0, 4.0};
        double[] expectedY = {0.0, 0.0, 0.0, 0.0};
        assertArrayEquals(expectedX, x, 1e-10);
        assertArrayEquals(expectedY, y, 1e-10);
    }
}
